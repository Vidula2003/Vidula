# Queen Amdi 4.0v💃🏻❤️ (Multi-Device version)

You can join Beta Testing WhatsApp Group by invite link :
<a href="https://chat.whatsapp.com/LhWHB9gftfwIv29C4etUHH">Beta Testing Whatsapp Group</a>

----

### License
This project is protected by the `GNU General Public License v3.0.`
Do not edit copyright messages!

### Disclaimer
`WhatsApp` name, its variations and logo are registered trademarks on Facebook. We have nothing to do with the registered trademark.
